<?php

namespace NRG_RANK\essentials;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\nbt\BigEndianNBTStream;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase 
{

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        switch ($command->getName())
        {
            case "heal":
                $player = $sender;
                if (isset($args[0]))
                {
                    if ($sender->hasPermission("essentials.healothers"))
                        $player = $this->getServer()->getPlayer($args[0]);
                }
                if ($player instanceof Player)
                {
                    $player->setHealth($player->getMaxHealth());
                    $sender->sendMessage("Successfully healed");
                }
                break;
            case "feed":
                $player = $sender;
                if (isset($args[0]))
                {
                    if ($sender->hasPermission("essentials.feedothers"))
                        $player = $this->getServer()->getPlayer($args[0]);
                }
                if ($player instanceof Player)
                {
                    $player->setFood($player->getMaxFood());
                    $player->setSaturation(20);
                    $sender->sendMessage("Successfully fed");
                }
                break;
            case "spawn":
                if ($sender instanceof Player) 
                {
                    $player->teleport($this->getServer()->getDefaultLevel()->getSafeSpawn());
                }
                break;
        }
        return true;
    }

}